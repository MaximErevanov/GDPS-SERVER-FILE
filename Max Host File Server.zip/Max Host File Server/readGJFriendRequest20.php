<?php
include "incl/relationships/readGJFriendRequest.php";
?>