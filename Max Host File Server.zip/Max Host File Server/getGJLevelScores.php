<?php
include "incl/scores/getGJLevelScores.php";
?>