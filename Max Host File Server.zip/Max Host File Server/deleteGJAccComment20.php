<?php
include "incl/comments/deleteGJAccComment.php";
?>