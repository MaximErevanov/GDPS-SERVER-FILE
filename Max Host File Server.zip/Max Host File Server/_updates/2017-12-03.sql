ALTER TABLE `roles` ADD `commandWeekly` INT NOT NULL DEFAULT '0' AFTER `commandDaily`;
