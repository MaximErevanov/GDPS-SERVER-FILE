UPDATE levels SET levelInfo = "" WHERE levelInfo = "0";
UPDATE levels SET secret = "" WHERE secret = "0";
UPDATE levels SET extraString = "" WHERE extraString = "0";