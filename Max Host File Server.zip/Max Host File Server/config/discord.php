<?php
$discordEnabled = false;
$secret = "please change this if you intend to use a discord bot with the server";
$bottoken = "please change this to a discord bot token if you use one";
?>