<?php
$servername = "localhost";
$port = 3306;
$username = "foxmax_db";
$password = "11w1988W";
$dbname = "foxmax_db";
?>
